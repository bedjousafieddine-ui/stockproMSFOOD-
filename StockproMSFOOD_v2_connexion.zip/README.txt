StockproMSFOOD — V1 avec connexion

Fonctions :
- connexion utilisateur
- compte administrateur initial : admin / admin123
- création d'utilisateurs depuis le menu Utilisateurs
- rôles Administrateur et Employé
- produits en cartons de 6, 12, 15, 20, 24, 30, 40, 50 ou 60 unités
- stock en cartons + unités restantes
- produits au poids
- entrées/sorties et historique
- tableau de bord

Important : cette V1 reste un prototype local. Les comptes sont stockés dans le navigateur.
Pour une vraie application multi-utilisateurs, il faudra un serveur, une base de données et des mots de passe hashés.
